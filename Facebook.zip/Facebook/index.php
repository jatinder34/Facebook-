<?php

require_once 'autoload.php';

$fb = new Facebook\Facebook([
  'app_id' => '443131782815113', // Replace {app-id} with your app id
  'app_secret' => '90612f2d41ca8ba3e68a108ee7fe9761',
  'default_graph_version' => 'v2.2',
  ]);

$helper = $fb->getRedirectLoginHelper();

$permissions = ['email']; // Optional permissions
$loginUrl = $helper->getLoginUrl('http://localhost/Facebook/fb-callback.php', $permissions);

echo '<a href="' . htmlspecialchars($loginUrl) . '">Log in with Facebook!</a>';